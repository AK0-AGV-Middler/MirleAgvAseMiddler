﻿namespace Mirle.Agv.Controller.Handler.TransCmdsSteps
{
    public interface ITransferStatus
    {
        void DoTransfer(MainFlowHandler mainFlowHandler);
    }
}