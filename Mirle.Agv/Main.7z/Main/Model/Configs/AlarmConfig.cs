﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Mirle.Agv.Model.Configs
{
    [Serializable]
    public class AlarmConfig
    {
        public string AlarmFileName { get; set; }
    }
}
